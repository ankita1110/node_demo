const mongoose=require('mongoose');
const express=require('express');
const bp=require('body-parser');
const ps=require('passport');
const pslocal=require('passport-local').Strategy;
const user=require('./model/user');
var app=express();
app.use(bp.json());
app.use(bp.urlencoded({extended:true}));
mongoose.Promise=global.Promise;
mongoose.connect('mongodb://localhost:27017/ankita');
app.use(require('express-session')({secret:'keyboard',resave:true,saveUninitialized:true}));


ps.use(new pslocal((username,password,done)=>{
    user.findOne({'username':username},(err,usern)=>{
        console.log(username);
        console.log(password);
        return done(null,usern);
    })

}))

 ps.serializeUser((user,cb)=>{
    cb(null,user);
 })

ps.deserializeUser((user,cb)=>{
    cb(null,user);
})

app.use(ps.initialize());
app.use(ps.session());

app.get('/',(req,res)=>{
    res.sendFile(__dirname+"/views/my.html");
    // res.sendFile('C:/Users/lcom160-two/WebstormProjects/untitled/pass_demo/views/my.html');
})

app.post('/login',ps.authenticate('local',{failureRedirect:'/'}),(req,res)=>{
    res.sendFile(__dirname+"/views/home.html");
})

app.listen(3000);
var mysql = require('mysql');
const express=require('express');
const bp=require('body-parser');
var app=express();
app.use(bp.json());


var con = mysql.createConnection({
    host: "sql10.freemysqlhosting.net",
    user: "sql10214314",
    password: "FEuuAdHU8d",
    database: "sql10214314"
});

app.post('/user',(req,res)=>{
    let name=req.body.name;
    let city=req.body.city;
    con.connect(function (err) {
    var s1="insert into ank(name,city)values('"+name+"','"+city+"')";
    con.query(s1);
    console.log("insert");
    res.send('inserting');

})
})
app.listen(3000);
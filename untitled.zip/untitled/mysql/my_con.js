const s1=require('mysql');
var c=s1.createConnection({
    host: "sql10.freemysqlhosting.net",
    user: "sql10214314",
    password: "FEuuAdHU8d",
    database: "sql10214314"
})

c.connect(function(err) {
    var s="CREATE TABLE ank (name VARCHAR(255), city VARCHAR(255))";

    c.query(s);
})




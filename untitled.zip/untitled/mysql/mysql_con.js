var mysql = require('mysql');

var con = mysql.createConnection({
    host: "sql10.freemysqlhosting.net",
    user: "sql10214314",
    password: "FEuuAdHU8d",
    database: "sql10214314"
});

//create table

// con.connect(function(err) {
//     // if (err) throw err;
//     // console.log("Connected!");
//     var sql = "CREATE TABLE ank (name VARCHAR(255), city VARCHAR(255))";
//     con.query(sql);
//     //     if (err) throw err;
// //     console.log("Table created");
// // });
// });


//insert record

// con.connect(function (err) {
//     var s1="insert into ank(name,city)values('ankita','surat')";
//     con.query(s1);
//
// })


//select record

con.connect(function(err){
    var s="select name from ank";
    con.query(s,function (err,result) {
        console.log(result);

    })
})

const {SHA256}=require('crypto-js');
const jwt=require('jsonwebtoken');

var data={
    id:10
}

var encode=jwt.sign(data,'123ab');
console.log(encode);

var decode=jwt.verify(encode,'123ab');
console.log(decode);


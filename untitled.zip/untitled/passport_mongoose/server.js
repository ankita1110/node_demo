const mongoose=require('mongoose');
var ex=require('express');
var ps=require('passport');
var stg=require('passport-local').Strategy;
const user=require('./model/user');
var bp=require('body-parser');
const jwt=require('jsonwebtoken');
var app=ex();
app.use(bp.json());
app.use(bp.urlencoded({ extended: true }));
app.set('views',__dirname+'/views');
app.set('view engine','ejs');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/ankita');
app.use(require('express-session')({secret:'keyboard',resave:true,saveUninitialized:true}));


app.use(function(req,res,next){
    if(req.url=='/login' || req.url=='/logout'){
        next();
    }else{
        if(req.session.passport){
            if(Object.keys(req.session.passport).length!=0) {
                next();
            }
            else{
                res.send(`you need to login first`);
            }
        }else{
            res.send(`you need to login first`);
        }

    }
});

ps.use(new stg((username,password,done) =>{
    console.log('start')
    user.findOne({'username':username},(err,usern)=> {
        console.log(username);
        console.log(password);
        if (err) {console.log(err); return done(err); /*returning error*/ }

        // check for not error and no user
        if (!usern) { console.log('no user found'); return done(null, false); }

        // check for valid user

        let d_p=jwt.verify(usern.password,'aaa');
        if (d_p !== password) { console.log('password do not match ', usern.password); return done(null, false); }

        // finally return valid user
        return done(null, usern);
    });
}));

ps.serializeUser((user, cb) => {
    cb(null, user);
});

// deserialize user object
ps.deserializeUser((user, cb) => {
    cb(null, user);
});

app.use(ps.initialize());
app.use(ps.session());


app.get('/',(req,res)=>{
    console.log(req.session);
    res.render('home',{user:req.user});
})

app.get('/login',(req,res)=>{
    res.render('login');
    // res.send("Hallo")
})


app.get('/sign',(req,res)=>{
    res.render('signup');
    // res.send("Hallo")
})
app.post('/su',(req,res)=>{
    let uname=req.body.username;

    let pwd=req.body.password;
    let e_p=jwt.sign(pwd,'aaa');
    console.log(uname);
    console.log(pwd);

    let u=new user({
        username:uname,
        password:e_p
    })

    u.save();

})




app.post('/login',ps.authenticate('local',{failureRedirect:'/login'}),(req,res)=>{
    res.redirect('/');
})

app.get('/profile',require('connect-ensure-login').ensureLoggedIn(),(req,res)=>{
    res.render('profile',{user:req.user});
})

app.get('/logout',(req,res)=>{
    req.logout();
    res.redirect('/');
})

app.get('/users', (req, res) => {

    user.find().then((mohs) => {
        res.status(200).send({ mohs });
    }, (e) => {
        res.status(400).send(e);
    });
});

app.listen(3000);





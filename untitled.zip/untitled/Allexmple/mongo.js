const m=require('mongodb').MongoClient;

m.connect('mongodb://localhost:27017/ankita',(err,db)=>{
    if(err){
        console.log('not connect');
    }

        console.log('connet');

//inserting recodr
// db.collection('moh').insertMany([{
//     text:'this is my function'
// },{text:'oh my god'}]);


//deleting recode

// db.collection('moh').deleteOne({text:'oh my god'});

 //update record
 //db.collection('moh').updateOne({text:'this is node js'},{$set:{text:'nodejs is a lan guage'}});

db.collection('moh').find({},{name:true,_id:false}).toArray().then((res)=>{
    console.log(res);
});

db.close();
});



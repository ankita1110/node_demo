const express=require('express');
const bo=require('body-parser');
var app=express();
app.use(bo.urlencoded({extended:true}));

app.get('/',(req,res)=>{
    res.send('message');
})

app.get('/name',(req,res)=>{
    res.send('name');
})

app.get('/name/:id',(req,res)=>{
    res.send(req.params.id);
})

app.get('/names',(req,res)=>{
    res.send(req.query.id);
})

app.get('/na',(req,res)=>{
    res.json({name:"ankita",city:"surat"});
})


app.post('/',(req,res)=>{
    res.send(req.body.name);
})

app.listen(3000,()=>{

})
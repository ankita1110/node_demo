const express=require('express');
const app=express();

var a1 = [ 1, 5, 6,7,8 ];
app.get('/',(req,res)=>{
    res.send(JSON.stringify(a1));
    res.end();
})

app.get('/a',(req,res)=>{
    console.log('ex');
    var index = a1.indexOf(6);
  //  console.log(index);

  //  console.log(a1[index]);
  //  res.send(index.toString());
    res.send(a1[index].toString());
    res.end();
})


//delete element
app.delete('/b',(req,res)=>{
    res.send(a1.splice (1, 1).toString());
    console.log(a1);
   // res.send(a1);

})

//given static range
app.get('/abc',(req,res)=>{
    res.send(a1.slice(1,3).toString());
})

//given dynamic range
app.get('/names',(req,res)=>{
    var q=req.query.id;
    var a=req.query.id1;
    res.send(a1.slice(q,a));
    console.log(q);

})

//sort and reverse
app.get('/so',(req,res)=>{
    var ss=a1.sort().reverse();
    res.send(ss.join(""));
})

app.get('/min',(req,res)=>{
    res.send(a1.sort().join(""));
})
//update
app.put('/pu',(req,res)=>{
  // console.log(a1);
    res.send(a1[1]=10);
    console.log(a1);
})
app.listen(3000);
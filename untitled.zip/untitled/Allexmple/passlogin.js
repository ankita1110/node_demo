// const express=require('express');
// const bp=require('body-parser');
// var passport = require('passport');
// var app=express();
//
// app.use(express.static('../exmple'));
//
// app.post('/login',
//     passport.authenticate('local', { successRedirect: '/',
//         failureRedirect: '/login',
//         failureFlash: true })
// );
//         app.listen(3000);

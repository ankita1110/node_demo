const express=require('express');
// const bp=require('body-parser');
// const expressValidator=require('express-validator');

const { check, validationResult } = require('express-validator/check');
//var expressValidator = require('express-validator');

var app=express();
// app.use(expressValidator);
app.use(express.static('../exmple'));

app.get('/',[check('username').isLength({min : 5})],(req,res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.send('must be 5');
    }
    //console.log("Hallo");
res.send(`username : ${req.query['username']} <br> password:${req.query['pwd']}`);
});

// app.get('/',(req,res)=>{
//     req.check('username');
//     var errors = req.validationErrors();
//     if(errors){
//         res.render('home',{
//             topicHead : 'Student Form',
//             errors : errors
//         });
//         console.log('Error');
//     }
// })
app.listen(3000,() => console.log("Server started"));


var ex=require('express');
var ps=require('passport');
var stg=require('passport-local').Strategy;
var db=require('./db');
//var app=ex();

ps.use(new stg((username,password,cb) =>{
    console.log('start')
    db.user.findByUsername(username,(err,user)=> {
        return cb(null, user);
    })

}))


ps.serializeUser((user,cb)=> {
    cb(null,user.id);

})

ps.deserializeUser((id,cb)=> {
    db.user.findById(id,(err,user)=> {
    if(err){
        return cb(err);
    }
    cb(null,user);
    })

})

var app=ex();
app.set('views',__dirname+'/views');
 app.set('view engine','ejs');
// // app.use(ex.static('views'))
 //app.use(require('morgan')('combined'));
//app.use(require('cookie-parser')());
 var bp=require('body-parser');
app.use(bp.json());
app.use(bp.urlencoded({ extended: true }));
app.use(require('express-session')({secret:'keyboard',resave:true,saveUninitialized:true}));

app.use(ps.initialize());
app.use(ps.session());

app.get('/',(req,res)=>{
    res.render('home',{user:req.user});
})

app.get('/login',(req,res)=>{
    res.render('login');
    // res.send("Hallo")
})


app.post('/login',ps.authenticate('local',{failureRedirect:'/login'}),(req,res)=>{
    res.redirect('/');
})

// app.post('/login',
//     ps.authenticate('local', { failureRedirect: '/login' }),
//     function(req, res) {
//         res.redirect('/');
//     });


app.get('/logout',(req,res)=>{
    req.logout();
    res.redirect('/');
})


app.get('/profile',require('connect-ensure-login').ensureLoggedIn(),(req,res)=>{
    res.render('profile',{user:req.user});
})


app.listen(3000);





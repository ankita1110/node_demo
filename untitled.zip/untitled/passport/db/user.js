var r=[{id:1,username:'ankita',password:'ankita'},{id:2,username:'bina',password:'secret1'}];

exports.findById= (id,cb)=> {
    process.nextTick(()=> {
        var idx = id-1;
        if (r[idx]) {
            cb(null, r[idx]);
        }
    })
}

exports.findByUsername=(username,cb)=> {
    process.nextTick(()=> {
        console.log('kya avya')
        for (var i=0,len=r.length;i<len;i++){
            var r1=r[i];
            if(r1.username===username){
                return cb(null,r1);
            }
        }
        return cb(null,null);
    })

}
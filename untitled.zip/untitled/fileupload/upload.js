const express=require("express");
const fileup=require("express-fileupload");
var app=express();
var path=require("path");

app.use(fileup());

app.get('/upload',(req,res)=>{
    res.sendFile(path.join(__dirname+"/views/fileup.html"));
})

app.post('/upload',(req,res)=>{
    if(req.files.sample==undefined)
        return res.status(400).send('no found');

    let f=req.files.sample;
    let uploadpath=path.join(__dirname+"/img/"+f.name);

    f.mv(uploadpath,(err)=>{
        if(err)
            return res.status(400).send(err).end();
    })
    res.status(200).send('success');
})

app.listen(3000);
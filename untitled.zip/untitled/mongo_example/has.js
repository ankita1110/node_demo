const {SHA256}=require('crypto-js');
const jwt=require('jsonwebtoken');

const bcrypt=require('bcryptjs');

//encrypt the password
var pass='123abc';
// bcrypt.genSalt(10,(err,salt)=>{
//     bcrypt.hash(pass,salt,(err,hash)=>{
//         console.log(
//
//         );
//     });
// });

//compare original password and encrypt password
var hp='$2a$10$ezNRmcPjkCmCqeRARCE.RO10LnpSWBiMGFm/gTi3pXvirVxEY0/Be';
bcrypt.compare('123',hp,(err,res)=>{
    console.log(res);
    }
)

const mongo=require('mongodb').MongoClient;
mongo.connect('mongodb://ankita:ankita@cluster0-shard-00-00-c1yro.mongodb.net:27017,cluster0-shard-00-01-c1yro.mongodb.net:27017,cluster0-shard-00-02-c1yro.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin',(err,client)=>{
    if(err){
       return console.log('error');
    }
    console.log('connecr');



    db.collection('mm').insertOne({
        text:'some'
    },(err,res)=> {
        if(err){
            console.log ('error',err);
        }
        console.log(JSON.stringify(res.ops));
    })
db.close();
})
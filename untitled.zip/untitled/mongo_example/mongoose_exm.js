const mongo=require('mongoose');
const {SHA256}=require('crypto-js');
const jwt=require('jsonwebtoken');
mongo.Promise=global.Promise;
mongo.connect('mongodb://localhost:27017/ankita');


var todo=mongo.model('aaj',{
    username:{
        type:String
    },
    password:{
        type:String
    }
})



var ntodo=new todo({
    username:'ankita',
    password:'ankita'
})

var token=jwt.sign(ntodo,'123abc');
console.log(token);
var decode=jwt.verify(token,'123abc');
console.log('decode',decode);

ntodo.save().then((d)=>{
    console.log('ok',d);
})


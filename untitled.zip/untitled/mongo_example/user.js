var mongoose=require('mongoose');
// {
//     email:'ankita@gmail.com',
//     password:'ankita',
//     tokens:[{
//         access:'auth',
//         token:'dasdddasdadadad'
// }]
// }

var u=mongoose.model('user',{
    email:{
        type:String,
        unique:true
    },
    password:{
        type:String
    },
    tokens:[{
        type:String,
        required:true
    }]
})

module.exports={u};
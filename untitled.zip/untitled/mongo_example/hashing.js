const {SHA256}=require('crypto-js');
const jwt=require('jsonwebtoken');




// var msg='I am user';
// var hash=SHA256(msg).toString();
// console.log(`message:${msg}`);
// console.log(`Hash:${hash}`);

var data={
    id:4
};

var token=jwt.sign(data,'123abc');
console.log(token);
var decode=jwt.verify(token,'123abc');
console.log('decode',decode);
// var tokan={
//     data,
//     hash:SHA256(JSON.stringify(data).toString())
// }


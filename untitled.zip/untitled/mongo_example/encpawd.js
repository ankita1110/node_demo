const mongoose=require('mongoose');
const {SHA256}=require('crypto-js');
const jwt=require('jsonwebtoken');
const bc=require('bcryptjs');
const bcrypt=require('bcrypt-nodejs');
mongoose.Promise=global.Promise;
mongoose.connect('mongodb://localhost:27017/ankita');
const schema=mongoose.Schema;

const user=new mongoose.Schema({
    username:{
        type:String
    },
    password:{
        type:String
    }
});


var us=mongoose.model('aaj',user);

var token = us({
    username:"mohini",
    password : bcrypt.hashSync('123456',bcrypt.genSalt(10),null)
})

token.save().then((res) => console.log(res))




// user.pre('save',function (next) {
//     var u=this;
//     if(u.isModified('password')){
//         var token=jwt.sign(this.password,'test123');
//         this.password=token;
//       //  var decode=jwt.verify(token,'test123');
//        // console.log('decode',decode);
//         next();
//     }
//     else{
//         next();
//     }
// });
//
//
// var test=new us({
//     username:"mohini",
//     password:"123456"
// });
//
// // var token=jwt.sign({
// //     username:"mohini",
// //     password:"test123"
// // },'test123');
// // console.log(token);
//
//
// // test.save(function (err,data) {
// //     if(err)
// //         console.log(err);
// //     else
// //         console.log('Success',data);
// //
// // });
//
//
// user.post('findOne',function(result,next){
//     console.log("start");
//         let aa=jwt.verify(result.password,'test123');
//         result.password =aa;
//         console.log(result);
//        // this.password=decode;
//         next();
// });
//
// // us.findOne({username:'mohini'},(err,data)=> {
// //     if(err)
// //         console.log(err);
// //     else{
// //         console.log('Success',data);
// //          var decode=jwt.verify(data.password,'test123');
// //          console.log('decode',decode)
// //     }
// //
// // });
// us.findOne({username:"mohini"}).then((data)=>{console.log(data);}).catch((err)=>{console.log(err)});
//
//
// // var decode=jwt.verify(token,'123abc');
// // console.log('decode',decode);
// // var decode=jwt.verify(test,'test123');
// // console.log('decode',decode);
//
//
// // us.findOne({username:'mohini'},(err,data)=> {
// //     if(err)
// //         console.log(err);
// //     else
// //         console.log('Success',data);
// //
// // });
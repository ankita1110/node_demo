var express = require('express');
var helmet = require('helmet');

// Create our Express application
var app = express();

// Implement Strict-Transport-Security
app.use(helmet.hsts({
    maxAge: 7776000000,
    includeSubdomains: true
}));

// Simple endpoint
app.get('/', function(req, res) {
    res.send('Time to secure your application...');
});

// Start the server
app.listen(3000);
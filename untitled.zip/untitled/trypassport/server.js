const mongoose=require('mongoose');
const passport=require('passport');
const stg=require('passport-local').Strategy;
const ex=require('express');
const bp=require('body-parser');
var app=ex();
app.use(bp.urlencoded({extended:true}));
var user=require('./model/user');
app.set('views',__dirname+'/views');

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/ankita');

passport.use(new stg(username,password,done)=>{
    user.findOne({'username':username},(err,u)=>{
        return done(null,u);
    })
})

